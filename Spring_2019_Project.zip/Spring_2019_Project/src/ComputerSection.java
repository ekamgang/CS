import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  ComputerSection extends JFrame implements ActionListener {
	
	private Computers hp = new Computers(399.99,"hp", "31/2050");
	private Computers Dell = new Computers(499.99,"Dell", "31/2050");
	private Computers Mac = new Computers(899.99,"MacBook", "31/2050");
	private JButton dell;
	private JButton mac;	
	private JButton HP, Back;
	private JLabel l;
	public 	 ArrayList<Computers> computers = new ArrayList<Computers>();

    

	
	
	// constructor
	ComputerSection(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your computer");
		add(l);
		HP = new JButton(hp.toString());
		add(HP);
		mac=new JButton(Mac.toString());
		add(mac);
		dell = new JButton(Dell.toString());
		add(dell);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			mac.addActionListener( this );
			HP.addActionListener( this );
			dell.addActionListener( this );
			computers.add(hp);
			computers.add(Dell);
			computers.add(Mac);
			Collections.sort(computers);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==mac) {
			System.out.println(Mac.toString());

 		}
		else if (evt.getSource()==HP) {
			System.out.println(hp.toString());
 		}else if (evt.getSource()==dell) {
			System.out.println(Dell.toString());

 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   ElectronicsSection().setVisible(true);
		}}
}
