import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  MeatSection extends JFrame implements ActionListener {
	
	private Meat beef  = new Meat(8.99,"beef", "05/31/2019");
	private Meat pork  = new Meat(10.99,"pork", "06/11/2019");
	private Meat chicken  = new Meat(6.99,"chicken", "07/20/2019");
	private Meat fish  = new Meat(13.99,"fish", "05/22/2019");
	ArrayList<Meat> meat = new ArrayList<Meat>();
	private JButton Back;
	private JButton Beef;
	private JButton Pork;	
	private JButton Chicken;
	private JButton Fish;
	private JLabel l;
    

	
	
	// constructor
	MeatSection(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your meat");
		add(l);
		Beef = new JButton(beef.toString());
		add(Beef);
		Pork=new JButton(pork.toString());
		add(Pork);
		Chicken = new JButton(chicken.toString());
		add(Chicken);
		Fish = new JButton(fish.toString());
		add(Fish);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			Fish.addActionListener( this );
			Pork.addActionListener( this );
			Chicken.addActionListener( this );
			Beef.addActionListener( this );
		
			meat.add(pork);
		meat.add(fish);
		meat.add(chicken);
		meat.add(beef);
		Collections.sort(meat);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Pork) {
			System.out.println(pork.toString());
		}
		else if (evt.getSource()==Fish) {
			System.out.println(fish.toString());


 		}if (evt.getSource()==Chicken) {
			
			System.out.println(chicken.toString());
			
 		}if (evt.getSource()==Beef) {
			System.out.println(beef.toString());
			

 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   FoodSection().setVisible(true);
		}}


}


