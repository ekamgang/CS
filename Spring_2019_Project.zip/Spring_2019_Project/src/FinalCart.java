import java.util.ArrayList;

import javax.swing.JFrame;

public class FinalCart extends JFrame {
	protected ArrayList<item> shopping_cart= new ArrayList<item>();
	protected double FinalPrice;

	public FinalCart() {
		
	}
public FinalCart(ArrayList<item> shopping_cart){
	this.shopping_cart= shopping_cart;
}
public void setCart( ArrayList<item> shopping_cart) {
	 this.shopping_cart =shopping_cart;
}
public String getCart(){
	String s=shopping_cart.toString();
	return s;
}
public void addPrice(item o) {
	  this.FinalPrice=this.FinalPrice+o.getPrice();
}
public double getFinalPrice() {
	double FP=0;
	for (int i = 0; i<shopping_cart.size();i++) {
		  FP=FP+shopping_cart.get(i).getPrice();

	}
	return FP;
}
}
