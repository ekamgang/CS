import java.util.*;

public class Suits extends Clothes implements Comparable<item>{
	public Suits() {
		
	}
	public Suits(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	}
public int compareTo(Suits o) {
	return (int) (this.getPrice()-o.getPrice());}
}
