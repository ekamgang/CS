import java.util.*;
import javax.swing.*;
import java.awt.*;

public class StoreDriver {
public static void main(String [] args) {
	Computers hp = new Computers(399.99,"hp", "2050-12");
	Computers Dell = new Computers(499.99,"Dell", "2050-07");
	Computers Mac = new Computers(899.99,"MacBook", "2050-04");
	
	Phones Samsung = new Phones(799.99,"Samsung_Notebook_10", "2050-01");
	Phones iphone = new Phones(999.99,"IphoneX", "2050-02");
	Phones nokia = new Phones(299.99,"Nokia", "2050-10");
	
	OverTheCounterDrugs advil = new OverTheCounterDrugs(9.99,"Advil", "2020-05");
	OverTheCounterDrugs bandaids = new OverTheCounterDrugs(6.99,"Bandaid", "2020-07");
	OverTheCounterDrugs loratadine = new OverTheCounterDrugs(13.99,"loratadine", "2020-07");
	 
	PrescriptionDrugs Opioids  = new PrescriptionDrugs(45.99,"Opioids", "2020-04");
	PrescriptionDrugs xanax  = new PrescriptionDrugs(50.99,"Xanax", "2020-08");
	PrescriptionDrugs valium  = new PrescriptionDrugs(60.50,"Valium", "2020-01");
	
	Fruit apple  = new Fruit(1.99,"apple", "2019-10");
	Fruit pineapple  = new Fruit(5.99,"pineapple", "2019-12");
	Fruit banana  = new Fruit(0.99,"banana", "2020-05");
	Fruit manguo  = new Fruit(1.00,"manguo", "2020-02");
	
	Meat beef  = new Meat(8.99,"beef", "2019-05");
	Meat pork  = new Meat(10.99,"pork", "2019-01");
	Meat chicken  = new Meat(6.99,"chicken", "2019-07");
	Meat fish  = new Meat(13.99,"fish", "2019-03");

	Shoes sneakers  = new Shoes(105.99,"nike", "2099-05");
	Shoes sneakers2  = new Shoes(99.99,"addidas", "2099-05");
	Shoes boots  = new Shoes(200.99,"boots", "2099-05");
	Shoes slippers  = new Shoes(50.99,"slippers", "2099-05");
	
	

	System.out.println("Items available in the store");
	

	ArrayList<item> store = new ArrayList<item>();
	// all items in the store
	
	ArrayList<Computers> computers = new ArrayList<Computers>();
	computers.add(Dell);
	computers.add(hp);
	computers.add(Mac);
	store.add(Dell);
	store.add(hp);
	store.add(Mac);
	System.out.println("Computers:");
	Collections.sort(computers);
	System.out.println(computers);
	

	
	ArrayList<Phones> phones = new ArrayList<Phones>();
	phones.add(Samsung);
	phones.add(iphone);
	phones.add(nokia);
	store.add(Samsung);
	store.add(iphone);
	store.add(nokia);
	System.out.println("phones:");
	Collections.sort(phones);
	System.out.println(phones);

	ArrayList<OverTheCounterDrugs> overTheCounterDrugs = new ArrayList<OverTheCounterDrugs>();
	overTheCounterDrugs.add(advil);
	overTheCounterDrugs.add(bandaids);
	overTheCounterDrugs.add(loratadine);
	store.add(advil);
	store.add(bandaids);
	store.add(loratadine);
	System.out.println("over The Counter Drugs");
	Collections.sort(overTheCounterDrugs);
	System.out.println(overTheCounterDrugs);
	
	ArrayList<PrescriptionDrugs> prescriptionDrugs = new ArrayList<PrescriptionDrugs>();
	prescriptionDrugs.add(Opioids);
	prescriptionDrugs.add(xanax);
	prescriptionDrugs.add(valium);
	store.add(Opioids);
	store.add(xanax);
	store.add(valium);
	System.out.println("prescription Drugs:");
	Collections.sort(prescriptionDrugs);
	System.out.println(prescriptionDrugs);
	
	ArrayList<Meat> meat = new ArrayList<Meat>();
	meat.add(beef);
    meat.add(fish);
    meat.add(pork);
    meat.add(chicken);
    store.add(beef);
    store.add(fish);
    store.add(pork);
    store.add(chicken);
    System.out.println("meats:");
	Collections.sort(meat);
	System.out.println(meat);
	
	ArrayList<Fruit> fruits = new ArrayList<Fruit>();
	fruits.add(manguo);
	fruits.add(apple);
	fruits.add(banana);
	fruits.add(pineapple);
	store.add(manguo);
	store.add(apple);
	store.add(banana);
	store.add(pineapple);
	System.out.println("fruits:");
	Collections.sort(fruits);
	System.out.println(fruits);
	
	ArrayList<Shoes> shoes = new ArrayList<Shoes>();
	shoes.add(sneakers);
	shoes.add(sneakers2);
	shoes.add(boots);
	shoes.add(slippers);
	store.add(sneakers);
	store.add(sneakers2);
	store.add(boots);
	store.add(slippers);
	System.out.println("shoes:");
	Collections.sort(shoes);
	System.out.println(shoes);
	
	ArrayList<Suits> suits = new ArrayList<Suits>();
	System.out.println("suits:");
	Collections.sort(suits);
	System.out.println(suits);
	
	
	MyFrame frame = new MyFrame();
    frame.setVisible( true );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	

    
	removeExpItem(store,0); //removing expired items
	Computers lenovo  = new Computers(130.99,"lenovo", "2089-05");
	addItem(store,lenovo);   //adding item
	Collections.sort(store);
	//System.out.println(store.toString());
	System.out.println("search in GUI OR search by name");
    Scanner console = new Scanner(System.in);
    String t = console.next();
    while(t!="exit") {
    System.out.print(searchByName(store, t));
    t = console.next();}
}




public static String searchByName(ArrayList<item> A,  String word) {
	for (int i =0; i<=A.size()-1;i++) {
		if (A.get(i).getName().equalsIgnoreCase(word)) {
		return A.get(i).toString();	
		}
	}
		return "Sorry. We don't have this item";
	
}



public static void removeExpItem(ArrayList<item> A, int x) {
	if (x>(A.size()-1)) {
		System.out.println();
	    }
			 else {
				 String currentDate ="2019-04";
	String t=currentDate.replace("-", "");
	String s=A.get(x).getExpDate();
	String p=s.replace("-", "");
	int y =Integer.parseInt(t);
	int z =Integer.parseInt(p);

		   if (y>z) {
			System.out.println( (A.get(x).getName()+" is expired, it has been thrown away"));
			A.remove(x);
			removeExpItem(A,x+1);
		}else {
			removeExpItem(A,x+1);
		}
	}
}

public static void addItem(ArrayList<item> A, Object o) {
	if( o  instanceof item){
		item other =(item) o;
		A.add(other);
	}
}

}
	
    
  