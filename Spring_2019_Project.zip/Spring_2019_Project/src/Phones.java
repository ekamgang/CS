import java.util.*;
import java.awt.*;

public class Phones extends Electronics implements Comparable<item> {
	public Phones(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
	} 
	public int compareTo(Phones o) {
		return (int) (this.getPrice()-o.getPrice());
		
	}
}
