import java.util.*;

public class Shoes extends Clothes implements Comparable<item>{
	public Shoes(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	}
public int compareTo(Shoes o) {
	return (int) (this.getPrice()-o.getPrice());}
}