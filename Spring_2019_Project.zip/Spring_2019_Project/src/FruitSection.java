import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  FruitSection extends JFrame implements ActionListener {
	
	private Fruit apple  = new Fruit(1.99,"apple", "5/21/2019");
	private Fruit pineapple  = new Fruit(5.99,"pineapple", "5/13/2019");
	private Fruit banana  = new Fruit(0.99,"banana", "05/20/2020");
	 private Fruit manguo  = new Fruit(1.00,"manguo", "02/07/2020");
	private ArrayList<Fruit> fruits = new ArrayList<Fruit>();
	private JButton Back;
	private JButton Apple;
	private JButton Pineapple;	
	private JButton Banana;
	private JButton Manguo;
	private JLabel l;

	
	
	// constructor
	
	 FruitSection(String title){

		this.setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your fruit");
		add(l);
		Apple = new JButton(apple.toString());
		add(Apple);
		Pineapple = new JButton(pineapple.toString());
		add(Pineapple);
		Banana = new JButton(banana.toString());
		add(Banana);
		Manguo = new JButton(manguo.toString());
		add(Manguo);
		
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			Banana.addActionListener( this );
			Apple.addActionListener( this );
			Pineapple.addActionListener( this );
			Manguo.addActionListener( this );
		
		fruits.add(manguo);
		fruits.add(apple);
		fruits.add(banana);
		fruits.add(pineapple);
		Collections.sort(fruits);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Apple) {
			System.out.println("Item:  "+apple.toString());
 		}
		else if (evt.getSource()==Manguo) {
			System.out.println("Item: "+manguo.toString());


 		}if (evt.getSource()==Banana) {
			System.out.println("Item: "+banana.toString());

 		}if (evt.getSource()==Pineapple) {
			System.out.println("Item: "+pineapple.toString());
			

 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   FoodSection().setVisible(true);
		}}


}