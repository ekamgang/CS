
public class Drugs extends item {
	public Drugs() {
		
	}
	public Drugs(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
	}
}
