import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class ClothSection extends JFrame implements ActionListener{
	// constructor
	JButton shoes,suits,Back;
	JLabel l;
	ClothSection( ){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("what kind of clothes are you looking for");
		add(l);
		shoes = new JButton("shoes");
		add(shoes);
		suits = new JButton("suits");
		add(suits);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
		shoes.addActionListener( this );
		suits.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==shoes) {
			 this.setVisible(false);
		       new ShoeSection().setVisible(true);
		}
		else if (evt.getSource()==suits) {
	        this.setVisible(false);
	        new SuitSection().setVisible(true);
		}	 else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   Section().setVisible(true);
		}
	}
}
