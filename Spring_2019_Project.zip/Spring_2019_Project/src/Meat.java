import java.util.*;
public class Meat extends Food implements Comparable<item>{
	public Meat(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	} 
	public int compareTo(Meat o) {
		return (int) (this.getPrice()-o.getPrice());	}
}