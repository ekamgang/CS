import java.util.*;

public class OverTheCounterDrugs extends Drugs implements Comparable<item> {
	public OverTheCounterDrugs(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	}
	public int compareTo(OverTheCounterDrugs o) {
		return (int) (this.getPrice()-o.getPrice());	}
}
