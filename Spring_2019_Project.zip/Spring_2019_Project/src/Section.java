import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;

public class Section extends JFrame implements ActionListener   {

	private JPanel p;
	private JButton Food;
	private JButton Drugs;
	private JButton Electronics;
	private JButton Clothes;
	private JButton Back;
	protected FoodSection FS = new FoodSection();
	

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */	public Section(String title) {
	 }
	public Section() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		p=new JPanel();
		p.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(p);
		p.setLayout(null);
		
		 Food = new JButton("Food");
		Food.setBounds(5, 109, 61, 25);
		p.add(Food);
		
		Clothes = new JButton("Clothes");
		Clothes.setBounds(323, 194, 97, 25);
		p.add(Clothes);
		
		 Electronics = new JButton("Electronics");
		Electronics.setBounds(0, 194, 97, 25);
		p.add(Electronics);
		
		Drugs = new JButton("Drugs");
		Drugs.setBounds(323, 109, 97, 25);
		p.add(Drugs);
		
	    Back = new JButton("Back");
		Back.setBounds(5, 0, 97, 25);
		p.add(Back);
		Back.addActionListener(this);
		
		
		Food.addActionListener( this);
		Drugs.addActionListener(this);
		Electronics.addActionListener(this);
		Clothes.addActionListener(this);
		
		JLabel lblChooseASection = new JLabel("Choose a section");
		lblChooseASection.setBounds(130, 58, 143, 92);
		p.add(lblChooseASection);
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Food) {
			 this.setVisible(false);
		        new FoodSection().setVisible(true);
		}
		else if (evt.getSource()==Drugs) {
			 this.setVisible(false);
		        new DrugSection().setVisible(true);
		} else if (evt.getSource()==Electronics) {
			 this.setVisible(false);
		        new ElectronicsSection().setVisible(true);	
		} else if (evt.getSource()==Clothes) {
			 this.setVisible(false);
		        new ClothSection().setVisible(true);
		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   MyFrame().setVisible(true);
		} 

	}
}
