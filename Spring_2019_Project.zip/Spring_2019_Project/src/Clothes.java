import java.util.*;

public class Clothes extends item {
	public Clothes() {
		
	}
	public Clothes(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
	}

}
