import java.util.*;

public class PrescriptionDrugs extends Drugs implements Comparable<item> {
	public PrescriptionDrugs(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	} 
	public int compareTo(PrescriptionDrugs o) {
		return (int) (this.getPrice()-o.getPrice());	}
}
