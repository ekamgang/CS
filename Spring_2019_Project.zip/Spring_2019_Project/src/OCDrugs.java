import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  OCDrugs extends JFrame implements ActionListener {
	
	OverTheCounterDrugs advil = new OverTheCounterDrugs(9.99,"Advil", "01/31/2020");
	OverTheCounterDrugs bandaids = new OverTheCounterDrugs(6.99,"Bandaid", "01/31/2020");
	OverTheCounterDrugs loratadine = new OverTheCounterDrugs(13.99,"loratadine", "01/31/2020");
	private ArrayList<OverTheCounterDrugs> overTheCounterDrugs = new ArrayList<OverTheCounterDrugs>();
	private JButton Back;
	private JButton Advils;	
	private JButton Bandaids;
	private JButton Loratadine;
	private JLabel l;

	
	
	// constructor
	
	 OCDrugs(){

		this.setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your fruit");
		add(l);
		Advils = new JButton(advil.toString());
		add(Advils);
		Bandaids = new JButton(bandaids.toString());
		add(Bandaids);
		
		Loratadine = new JButton(loratadine.toString());
		add(Loratadine);
		
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			Loratadine.addActionListener( this );
			Advils.addActionListener( this );
			Bandaids.addActionListener( this );
		
			overTheCounterDrugs.add(advil);
			overTheCounterDrugs.add(bandaids);
			overTheCounterDrugs.add(loratadine);
			Collections.sort(overTheCounterDrugs);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Advils) {
			System.out.println(advil.toString());
			
 		}
		else if (evt.getSource()==Loratadine) {
			
			System.out.println(loratadine.toString());
			


 		}if (evt.getSource()==Bandaids) {
		
			System.out.println(bandaids.toString());
			

 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   DrugSection().setVisible(true);
		}}


}