import java.awt.*;
import java.awt.Event.*;
import javax.swing.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SuitSection extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JButton Back;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public SuitSection() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 500, 500);
		contentPane =new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		 Back = new JButton("Back");
		Back.addActionListener(this);
		
		JLabel lblItemAtThe = new JLabel("THESE ITEM AT THE MOMENT");
		lblItemAtThe.setFont(new Font("Javanese Text", Font.BOLD | Font.ITALIC, 19));
		
		JLabel lblSorryWeAre = new JLabel("SORRY, WE ARE OUT OF");
		lblSorryWeAre.setFont(new Font("Javanese Text", Font.BOLD | Font.ITALIC, 19));
			
			
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Back)
						.addComponent(lblItemAtThe, GroupLayout.PREFERRED_SIZE, 342, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblSorryWeAre, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(118, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(Back)
					.addGap(193)
					.addComponent(lblSorryWeAre)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblItemAtThe)
					.addContainerGap(87, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   ClothSection().setVisible(true);
		}
	}
}
