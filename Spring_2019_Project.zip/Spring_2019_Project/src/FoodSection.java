import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class FoodSection extends JFrame implements ActionListener{
	// constructor
	JButton Fruits,Meat, Back;
	JLabel l;
	FoodSection(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("what kind of food are you looking for");
		add(l);
		Fruits = new JButton("Fruits");
		add(Fruits);
		Meat = new JButton("Meat");
		add(Meat);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
		Meat.addActionListener( this );
		Fruits.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Fruits) {
			 this.setVisible(false);
		      new FruitSection("fruits").setVisible(true);
		}
		else if (evt.getSource()==Meat) {
	        this.setVisible(false);
	        new MeatSection().setVisible(true);
		}	 else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   Section().setVisible(true);
		}}


}
