
public class Electronics extends item{
	public Electronics() {
		
	}
	public Electronics(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
	}
}
