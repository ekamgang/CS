import java.util.*;
public class Fruit extends Food implements Comparable<item> {
	public Fruit(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
		} 
	public int compareTo(Fruit o) {
		return (int) (this.getPrice()-o.getPrice());
	}

}
