import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  PhoneSection extends JFrame implements ActionListener {
	
	private Phones Samsung = new Phones(799.99,"Samsung Notebook 10", "31/2050");
	private Phones iphone = new Phones(999.99,"Iphone X", "31/2050");
	private Phones nokia = new Phones(299.99,"Nokia", "31/2050");
	
	private ArrayList<Phones> phones = new ArrayList<Phones>();
	private JButton Back;
	private JButton samsung;
	private JButton Iphone;	
	private JButton Nokia;
	private JLabel l;
    

	
	
	// constructor
	PhoneSection(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your phone");
		add(l);
		Nokia = new JButton(nokia.toString());
		add(Nokia);
		Iphone = new JButton(iphone.toString());
		add(Iphone);
		samsung = new JButton(Samsung.toString());
		add(samsung);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			Iphone.addActionListener( this );
			samsung.addActionListener( this );
			Nokia.addActionListener( this );
		
			phones.add(Samsung);
			phones.add(iphone);
			phones.add(nokia);
			Collections.sort(phones);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Iphone) {
			System.out.println(iphone.toString());
		}
		else if (evt.getSource()==Nokia) {
			System.out.println(nokia.toString());

 		}else if (evt.getSource()==samsung) {
			System.out.println(Samsung.toString());

 		
 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   ElectronicsSection().setVisible(true);
		}}


}