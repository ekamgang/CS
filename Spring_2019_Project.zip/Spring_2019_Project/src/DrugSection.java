import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class DrugSection extends JFrame implements ActionListener{
	// constructor
	JButton overTheCounterDrugs,prescriptionDrugs, Back;
	JLabel l;
	DrugSection( ){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("what kind of drug are you looking for");
		add(l);
		overTheCounterDrugs = new JButton("over the counter drugs");
		add(overTheCounterDrugs);
		prescriptionDrugs = new JButton("prescription Drugs");
		add(prescriptionDrugs);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
		overTheCounterDrugs.addActionListener( this );
		prescriptionDrugs.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==overTheCounterDrugs) {
			 this.setVisible(false);
		      new OCDrugs().setVisible(true);
		}
		else if (evt.getSource()==prescriptionDrugs) {
	        this.setVisible(false);
	        new PRDrugs().setVisible(true);
		}	 else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   Section().setVisible(true);
		}
	}
}
