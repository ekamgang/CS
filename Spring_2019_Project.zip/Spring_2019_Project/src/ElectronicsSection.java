import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class ElectronicsSection extends JFrame implements ActionListener{
	// constructor
	JButton phones,computers, Back;
	JLabel l;
	ElectronicsSection( ){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("what kind of electronics are you looking for");
		add(l);
		phones = new JButton("phoness");
		add(phones);
		computers = new JButton("computers");
		add(computers);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
		phones.addActionListener( this );
		computers.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==phones) {
			 this.setVisible(false);
		      new PhoneSection().setVisible(true);
		}
		else if (evt.getSource()==computers) {
	        this.setVisible(false);
	        new ComputerSection().setVisible(true);
		}	 else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   Section().setVisible(true);
		}
	}
}
