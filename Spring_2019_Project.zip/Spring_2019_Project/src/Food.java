
public class Food extends item {
	public Food() {
		
	}
	public Food(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);	}
}
