import javax.swing.*;
import java.awt.*;
public class item implements Comparable<item>{
	private double price;
	private String name;
	private String expDate;

	public item() {
		
	}
	
	public item(double p, String n, String ed) {
		p=price;
		n=name;
		ed=expDate;
		
	}
	public void setPrice(double price) {
		this.price=price;
	}
	public void setExpDate(String expDate) {
		this.expDate=expDate;
	}
	public void setName(String name) {
		this.name=name;
	}
	public double getPrice() {
		return price;
	}
	public String getExpDate() {
		return expDate;
	}
	public String getName() {
		return name;
	}
	
	public String toString() {
		return  getName() +"---"+ getPrice()+ "$---"+ getExpDate();

	}
	public int compareTo(item o) {
		return  this.getName().compareTo(o.getName());	}
}
