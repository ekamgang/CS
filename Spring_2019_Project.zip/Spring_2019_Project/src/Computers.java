import java.util.*;

public class Computers extends Electronics implements Comparable<item> {
	public Computers(double p, String n, String ed) {
		setPrice(p);
		setName(n);
		setExpDate(ed);
	} 
	public int compareTo(Computers o) {
		return (int) (this.getPrice()-o.getPrice());	}
}
