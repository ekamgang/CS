import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  ShoeSection extends JFrame implements ActionListener {
	
	private Shoes sneakers  = new Shoes(105.99,"nike", "05/31/2099");
	private Shoes sneakers2  = new Shoes(99.99,"addidas", "05/31/2099");
	private Shoes boots  = new Shoes(200.99,"london boots", "05/31/2099");
	private Shoes slippers  = new Shoes(50.99,"slippers", "05/31/2099");
	ArrayList<Shoes> shoes = new ArrayList<Shoes>();
	private JButton Sneaker;
	private JButton Back;
	private JButton Sneakers2;	
	private JButton Slippers;
	private JButton Boots;
	private JLabel l;
    

	
	
	// constructor
	ShoeSection(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your shoe");
		add(l);
		Sneaker = new JButton(sneakers.toString());
		add(Sneaker);
		Sneakers2=new JButton(sneakers2.toString());
		add(Sneakers2);
		Boots = new JButton(boots.toString());
		add(Boots);
		Slippers= new JButton(slippers.toString());
		add(Slippers);
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			Sneaker.addActionListener( this );
			Sneakers2.addActionListener( this );
			Boots.addActionListener( this );
			Slippers.addActionListener( this );
		
			shoes.add(sneakers);
			shoes.add(sneakers2);
			shoes.add(boots);
			shoes.add(slippers);
			Collections.sort(shoes);		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==Sneaker) {
			System.out.println(sneakers.toString());
		}
		else if (evt.getSource()==Sneakers2) {
			System.out.println(sneakers2.toString());


 		}if (evt.getSource()==Boots) {
			
			System.out.println(boots.toString());
			
 		}if (evt.getSource()==Slippers) {
			System.out.println(slippers.toString());
			

 		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   ClothSection().setVisible(true);
		}}


}


