import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
 class MyFrame extends JFrame implements ActionListener{
	// constructor
	JButton access,exit;
	JLabel l;
   
	MyFrame(String title){
		
	}

	MyFrame(){
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("This is the inventory of the store");
		add(l);
		access = new JButton("look for item");
		add(access);
		exit = new JButton("exit");
		add(exit);
		// Who is going to listen when you click the button? 
		access.addActionListener( this );
		exit.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==access) {
			 this.setVisible(false);
		       new Section().setVisible(true);
		}
		else if (evt.getSource()==exit) {
	        System.exit(0);
		}	}


}