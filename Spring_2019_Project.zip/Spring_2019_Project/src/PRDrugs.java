import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.*;

class  PRDrugs extends JFrame implements ActionListener {
	
	PrescriptionDrugs Opioids  = new PrescriptionDrugs(45.99,"Opioids", "01/31/2020");
	PrescriptionDrugs xanax  = new PrescriptionDrugs(50.99,"Xanax", "01/31/2020");
	PrescriptionDrugs valium  = new PrescriptionDrugs(60.50,"Valium", "01/31/2020");
	
	ArrayList<PrescriptionDrugs> prescriptionDrugs = new ArrayList<PrescriptionDrugs>();

		private JButton Back;
	private JButton opiods;	
	private JButton Xanax;
	private JButton Valium;
	private JLabel l;

	
	
	// constructor
	
	 PRDrugs(){

		this.setLayout (new FlowLayout());
		setBounds (50,50, 300, 200);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		l = new JLabel ("choose your fruit");
		add(l);
		opiods = new JButton(Opioids.toString());
		add(opiods);
		Xanax = new JButton(xanax.toString());
		add(Xanax);
		
		Valium = new JButton(valium.toString());
		add(Valium);
		
		 Back = new JButton("Back");
			Back.setBounds(5, 0, 97, 25);
			add(Back);
			Back.addActionListener(this);
		// Who is going to listen when you click the button? 
			opiods.addActionListener( this );
			Xanax.addActionListener( this );
			Valium.addActionListener( this );
		
			prescriptionDrugs.add(Opioids);
			prescriptionDrugs.add(xanax);
			prescriptionDrugs.add(valium);
			Collections.sort(prescriptionDrugs);
		
	}
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()==opiods) {
			
			System.out.println(Opioids.toString());
			}
		else if (evt.getSource()==Xanax) {
			System.out.println(xanax.toString());
			
 		}if (evt.getSource()==Valium) {
				System.out.println(valium.toString());
		} else if (evt.getSource()==Back) {
			 this.setVisible(false);
		      new   DrugSection().setVisible(true);
		}}


}