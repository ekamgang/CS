import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class Counter extends JFrame implements ActionListener{
	// constructor
	JButton push;
	JLabel l;
	int count;
	Counter(String title){
		super (title);
		setLayout (new FlowLayout());
		setBounds (50,50, 100, 100);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		count = 0;
		l = new JLabel ("Pushes:"+count);
		add(l);
		push = new JButton("push me");
		add(push);
		// Who is going to listen when you click the button? 
		push.addActionListener( this );
	}
	public void actionPerformed(ActionEvent evt) {
		count +=1;
		if (count%2==0) {
			getContentPane().setBackground(Color.white);

		} else {
			getContentPane().setBackground(Color.blue);
		}
		
		l.setText("Pushes:"+count);
	}
}
public class testListener {
public static void main(String[] args) {
	Counter blfrm = new Counter("Painting button");
	blfrm.setVisible(true);	
}
}

