import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class CB extends JFrame implements ActionListener{
	// constructor
	private JLabel saying;
	private JCheckBox bold, italic;
	CB(String title){
		super (title);
		setLayout (new FlowLayout());
		setBounds (50,50, 500, 500);
		saying = new JLabel("Say with Style!");
		saying.setFont(new Font("Helvetica", Font.PLAIN,30));
		bold = new JCheckBox("Bold");
		italic = new JCheckBox("Italic");
		italic.setBackground(Color.cyan);
		add(saying);
		add(bold);
		add(italic);
		bold.addActionListener(this);
		italic.addActionListener(this);
	}
	public void actionPerformed(ActionEvent evt) {
		int num = 30;
		int Style = Font.PLAIN;
		if (bold.isSelected()) {
			italic.setSelected(false);
			Style = Font.ITALIC; 
			num = 10;
			saying.setText("OOPS");
			};
		if (italic.isSelected()) {
			bold.setSelected(false);
			Style = Font.BOLD;	
			num = 35;
			saying.setText("ERROR");
		}
		saying.setFont(new Font("Helvetica",Style,num));
	}
}
public class TestChkBox {
public static void main(String[] args) {
	CB cb = new CB("ChkBox");
	cb.setVisible(true);
}
}
