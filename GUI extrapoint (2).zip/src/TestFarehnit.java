
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
class FC extends JFrame implements ActionListener{
	// constructor
	private JLabel ftext = new JLabel("Enter Fahrenheit temperature"), ctext = new JLabel("Centigrade temperature"), rtext = new JLabel("---");
	private JTextField f = new JTextField(5);
	
	FC(String title){
		super (title);
		setLayout (new FlowLayout());
		setBounds (50,50, 300, 100);
		f.addActionListener( this );
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		add(ftext);
		add(f);
		add(ctext);
		add(rtext);
	}
	public void actionPerformed(ActionEvent evt) {
		double ft,ct;
		String s = f.getText();
		ft = Double.parseDouble(s);
		ct = (ft-32)*5/9;
		rtext.setText(""+ct);
	}
}
public class TestFarehnit {
public static void main(String[] args) {
	FC fc = new FC("F2C");
	fc.setVisible(true);
}
}